import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("アホでもわかるONE PIECE")

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (80, 80, 80)

font_title = pygame.font.SysFont("msgothic", 60)
font_button = pygame.font.SysFont("msgothic", 36)

button = pygame.Rect(100, 300, 200, 50)

try:
    image = pygame.image.load("ルフィ.png")
    image = pygame.transform.scale(image, (400, 400))
except:
    image = None

game_started = False

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if not game_started and button.collidepoint(event.pos):
                game_started = True

    if game_started:
        screen.fill(BLACK)
        start_text = font_title.render("リッキー先生はイケメン", True, WHITE)
        screen.blit(start_text, (300, 250))

    else:
        screen.fill(WHITE)

        title_surface = font_title.render("ONE PIECE", True, BLACK)
        screen.blit(title_surface, (100, 50))

        pygame.draw.rect(screen, GRAY, button)
        button_text = font_button.render("スタート", True, WHITE)
        screen.blit(button_text, (button.x + 20, button.y + 10))

        if image:
            screen.blit(image, (550, 100))

    pygame.display.flip()
